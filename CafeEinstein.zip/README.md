# Café Einstein - Deployment Guide

Denne pakke indeholder alt, du behøver for at få din hjemmeside med AI-chatbot live.

## Indhold
- **index.html**: Hjemmesiden med hero, menu, events, bookingformular, cookie-banner og chatbot.
- **api/chat.js**: Serverless backendfil til AI.
- **README.md**: Enkel trin-for-trin guide til deployment og API-nøgle.

## Trin-for-trin Deployment (Vercel)

1. Opret en konto på [Vercel](https://vercel.com).
2. Installer Node.js på din computer.
3. Gem denne mappe på din computer som `CaféEinstein`.
4. Åbn terminalen i mappen og kør:

   ```bash
   npm init -y
   npm install openai
   ```

5. Tilføj din OpenAI API-nøgle i Vercel:
   - Gå til dit projekt → **Settings → Environment Variables**
   - **Name:** OPENAI_API_KEY
   - **Value:** (din OpenAI API-nøgle, fx `sk-XXXXXX`)
6. Upload hele mappen til Vercel via **Import from Local Folder**.
7. Tryk **Deploy**.
8. Når deployment er færdig, får du et link til din live hjemmeside.

## Test AI
- Gå til hjemmesiden.
- Skriv noget i chatboksen og AI’en vil svare.

## Træning af AI
- AI’en er allerede promptet til at svare som Café Einstein-assistent.
- Du kan tilføje mere specifik info om menu, priser, events osv. ved at ændre `system` prompt i `api/chat.js`.